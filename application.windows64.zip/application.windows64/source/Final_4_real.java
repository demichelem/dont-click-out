import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Final_4_real extends PApplet {


SoundFile sound;
SoundFile file;
SoundFile []sounds=new SoundFile[13];
Delay delay;

int SoundFile[];
float x,y,z;
float h,w;
float ex,ey,bex,bey;
float rectcurveT,rectcurveB,topbarcurve;
float redx, redy, reds;
float yellowx,yellowy,yellows;
float grayx, grayy, grays;
float a,b,c,d;
int c1;
float stroke;
float r;
float amp;
PImage img;
int elapsed;
int lastTime;



 

public void setup(){

  
  sounds[0] = new SoundFile(this, "please dont close out.wav");
  sounds[1] = new SoundFile(this, "ill give you anything.wav");
  sounds[2] = new SoundFile(this, "if you close it ill die.wav");
  sounds[3] = new SoundFile(this, "think about my family.wav");
  sounds[4] = new SoundFile(this, "what would your mother say.wav");
  sounds[5] = new SoundFile(this, "am i not good enough for u.wav");
  sounds[6] = new SoundFile(this, "please move your mouse.wav");
  sounds[7] = new SoundFile(this, "i i thought i could trust you.wav");
  sounds[8] = new SoundFile(this, "please.wav");
  sounds[9] = new SoundFile(this, "my life so short so sad.wav");
  sounds[10] = new SoundFile(this, "no please no.wav");
  sounds[11] = new SoundFile(this, "x marks the spot.wav");
  sounds[12] = new SoundFile(this, "please im sorry.wav");
 
  
  
  
  x=width/2;
  y=height/2;
  w=700;
  h=500;
  ex=50;
  ey=50;
  bex=750;
  bey=72;
  rectcurveT = 8;
  rectcurveB = 3;
  topbarcurve = 5;
  redx = 62;
  redy = 62;
  reds = 11;
  yellowx = 82;
  yellowy = 62;
  yellows = 11;
  grayx = 102;
  grayy = 62;
  grays = 11;
  a=59;
  b=59;
  c=64;
  d=64;
  c1=0;
  stroke = .8f;
  r = 1;
  amp = .25f;
  img = loadImage("IMG_3368.PNG");
  
  
  // Load a soundfile from the /data folder of the sketch and play it back
  sound = new SoundFile(this, "breath.wav");
  sound.play();
  sound.amp(amp);
  sound.loop();
  sound.rate(r);
  
  //sound ideas:
  //1.please no no no please dont close out
  //2.I'll give you anything PLEASE don't click 
  //3.NO no no no 
  //4.I'll cut off my arm! You want my arm? I'll cut off my mom's arm! Please don't x out
  //5.if you close it, i'll die!
  //6.please leave me be! I've lived such a short life!
  //7.my lifespan is only as long as you allow it to be! please!
  //8.think about my family!
  //9.am i only a program to you? a series of ones and zeros to be mocked???
  //10. Alas poor program! Ye knew him not!
  //11. What would your mother say if she knew you KILLED me
  //12. please. i'm sorry. 
  //13. Am I not good enough for you? Was I ever good enough for you???
  //14. please please move your mouse off the x
  //15. x marks the spot huh? my spot? my grave? the place of my death???
  //16. no please no
  //17. my life! so short! so sad! confined to your screen and your mercy
  //18. hey. I know you really want to press on that x but I'm begging you please don't
  //19. please
  //20. I thought I could trust you
}

 

  

  //751,715
 

public void draw(){
  //body
 
  println(mouseX,mouseY);
  background(0xff587EB2);
  imageMode(CENTER);
 image(img,400,300,88,120);
  displayWindow();
  hoverRules();
  closeOut();
  closeAudio();
  open();
  sound.rate(r);
   if(mouseX>width-85 && mouseX<width-49)
  { 
    r = 0.45f;
    amp = 0.8f;
}
 if(mouseX>width-228 && mouseX<width-85)
  { 
    r = 0.55f;
    amp = 1;
}
if(mouseX>width-452 && mouseX<width-228)
  { 
    r = 0.70f;
    amp = 1.2f;
}
if(mouseX>width-500 && mouseX<width-452)
  { 
    r = 0.90f;
    amp = 1.4f;
}
if(mouseX>width-550 && mouseX<width-500)
  { 
    r = 1;
    amp = 1.5f;
}
if(mouseX>width-650 && mouseX<width-550)
  { 
    r = 1.1f;
    amp = 1.6f;
}

if(mouseX>width-700 && mouseX<width-650)
  { 
    r = 1.15f;
    amp = 1.8f;
}


if(mouseX>width-749 && mouseX<width-700)
  { 
    r = 1.2f;
    amp = 2;
}

 if(mouseX>width-743 && mouseX<width-732 && mouseY>height-541 && mouseY<height-531)
  {
    r = 1.5f;
    amp = 5;
  }
//572 717

//51,123

}

public void displayWindow(){
  fill(0);
  rectMode(CENTER);
  noStroke();
  rect(x,y,w,h,rectcurveT,rectcurveT,rectcurveB,rectcurveB);
  fill(200);
  rectMode(CORNERS);
  noStroke();
  rect(ex,ey,bex,bey,topbarcurve,topbarcurve,0,0);
  //red x
  ellipseMode(CENTER);
  fill(0xffFA6149);
  stroke(0xffB2551B);
  strokeWeight(.2f);
  ellipse(redx,redy,reds,reds);
  //yellow x
  fill(0xffF5C72F);
  stroke(0xffB28F1B);
  strokeWeight(.2f);
  ellipse(yellowx,yellowy,yellows,yellows);
  //gray x
  fill(190);
  stroke(125);
  strokeWeight(.2f);
  ellipse(grayx,grayy,grays,grays);
}

public void hoverRules(){
  if(mouseX>width-743 && mouseX<width-732 && mouseY>height-541 && mouseY<height-531)
  {
    stroke(c1);
    strokeWeight(stroke);
  line(59,59,64,64);
  line(64,59,59,64);
  }
  if(mouseX>width-723 && mouseX<width-712 && mouseY>height-541 && mouseY<height-531)
  {
     stroke(c1);
      strokeWeight(stroke);
  line(78,62,85,62);
}
}

public void closeOut(){
  if(mousePressed){
    if(mouseX>width-743 && mouseX<width-732){
      println("close out");
      rectMode(CENTER);
    noStroke();
    fill(0xff587EB2);
    rect(400,300,width,height);
   x=0;
  y=0;
  w=0;
  h=0;
  ex=0;
  ey=0;
  bex=0;
  bey=0;
  rectcurveT = 0;
  rectcurveB = 0;
  topbarcurve = 0;
  redx = 0;
  redy = 0;
  reds = 0;
  yellowx = 0;
  yellowy = 0;
  yellows = 0;
  grayx = 0;
  grayy = 0;
  grays = 0;
  c1=color(88, 126, 178);
  stroke = 0;
  sound.stop();
  file.stop();
 

  
  }
  }
    
        

      
  {
    
    
  }

}
  public void open(){
     if(mousePressed){
    if(mouseX>width-431 && mouseX<width-368){
      println("open");
  x=width/2;
  y=height/2;
  w=700;
  h=500;
  ex=50;
  ey=50;
  bex=750;
  bey=72;
  rectcurveT = 8;
  rectcurveB = 3;
  topbarcurve = 5;
  redx = 62;
  redy = 62;
  reds = 11;
  yellowx = 82;
  yellowy = 62;
  yellows = 11;
  grayx = 102;
  grayy = 62;
  grays = 11;
  a=59;
  b=59;
  c=64;
  d=64;
  c1=0;
  stroke = .8f;
  sound.play();
   sound.amp(amp);
  sound.loop();
  sound.rate(r);
  }
  }
    
    
  }
  public void closeAudio(){
   elapsed = millis() - lastTime;
   if (elapsed >= 1500) {
    int z =(int)random(sounds.length);
   file = sounds[z];
   if(mouseX>width-743 && mouseX<width-732 && mouseY>height-541 && mouseY<height-531) 
  {sounds[z].play();
  } 
  lastTime = millis();
   }
   //if sound [] playing then  5 second delay

   
  }

    //this works but takes up too much memory
  //delay = new Delay(this);
  //delay.process(file,1000);
  
  //I want to delay only the sound Array and nothing else
  public void settings() {  size(800,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Final_4_real" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
